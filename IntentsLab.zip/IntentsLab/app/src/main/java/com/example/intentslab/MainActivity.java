package com.example.intentslab;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

import java.io.IOException;

public class MainActivity extends AppCompatActivity {

    final String KEY_NAME="name";
    final String KEY_FATHERNAME="fatherName";
    final String KEY_REG="reg";
    final String KEY_CGPA="cgpa";
    final String KEY_SEMESTER="semester";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final Button submit=(Button) findViewById(R.id.submit);
        final EditText name=(EditText) findViewById(R.id.name);
        final EditText father=(EditText) findViewById(R.id.fatherName);
        final EditText reg=(EditText) findViewById(R.id.reg);
        final EditText cgpa=(EditText) findViewById(R.id.cgpa);
        final EditText semester=(EditText) findViewById(R.id.semester);
        final Button upload=(Button) findViewById(R.id.upload);


        Intent intent=getIntent();
        Bundle state=intent.getBundleExtra("editState");
        if(state!=null){
            name.setText(state.getString(KEY_NAME).toString());
            father.setText(state.getString(KEY_FATHERNAME).toString());
            reg.setText(state.getString(KEY_REG).toString());
            cgpa.setText(state.getString(KEY_CGPA).toString());
            semester.setText(state.getString(KEY_SEMESTER).toString());
        }
        upload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent uploadImageIntent=new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(uploadImageIntent,1);
            }
        });
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                submitToActivity(name.getText().toString(),father.getText().toString(),reg.getText().toString(),
                        cgpa.getText().toString(),semester.getText().toString());
            }
        });

    }
    @Override
    protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==1 && resultCode==RESULT_OK && data!=null){
            Uri selectedImage=data.getData();
            try {
                Bitmap bitmap=MediaStore.Images.Media.getBitmap(this.getContentResolver(),selectedImage);
                ImageView imageView=(ImageView) findViewById(R.id.imageView);
                imageView.setImageBitmap(bitmap);
                Button upload=(Button) findViewById(R.id.upload);
                upload.setVisibility(View.GONE);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
    public void submitToActivity(String name,String father,String reg,String cgpa,String semester){
        Bundle state=new Bundle();
        state.putString(KEY_NAME,name);
        state.putString(KEY_FATHERNAME,father);
        state.putString(KEY_REG,reg);
        state.putString(KEY_CGPA,cgpa);
        state.putString(KEY_SEMESTER,semester);

        Intent intent=new Intent(this,SecondActivity.class);
        intent.putExtra("state",state);
        startActivity(intent);
    }
}
