package com.example.intentslab;

import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class SecondActivity extends AppCompatActivity {
    final String KEY_NAME = "name";
    final String KEY_FATHERNAME = "fatherName";
    final String KEY_REG = "reg";
    final String KEY_CGPA = "cgpa";
    final String KEY_SEMESTER = "semester";

    @Override
    protected void onCreate(Bundle savedStateInstance) {
        super.onCreate(savedStateInstance);
        setContentView(R.layout.second_activity);

        TextView name = (TextView) findViewById(R.id.text_name);
        TextView father = (TextView) findViewById(R.id.text_father);
        TextView reg = (TextView) findViewById(R.id.text_reg);
        TextView cgpa = (TextView) findViewById(R.id.text_cgpa);
        TextView semester = (TextView) findViewById(R.id.text_semester);
        Button edit = (Button) findViewById(R.id.Edit);
        Button call = (Button) findViewById(R.id.Call);
        Button send=(Button) findViewById(R.id.Send);

        final Intent intent = getIntent();
        final Bundle state = intent.getBundleExtra("state");
        final String name_text = state.getString(KEY_NAME).toString();
        final String father_text = state.getString(KEY_FATHERNAME).toString();
        final String cgpa_text = state.getString(KEY_CGPA).toString();
        final String reg_text = state.getString(KEY_REG).toString();
        final String semester_text = state.getString(KEY_SEMESTER).toString();

        if (state != null) {
            name.setText("Name: " + name_text);
            father.setText("Father's Name: " + father_text);
            reg.setText("Registration Number: " + reg_text);
            cgpa.setText("CGPA: " + cgpa_text);
            semester.setText("Semester " + semester_text);
        }
        edit.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                editImplementation(name_text,father_text,reg_text,cgpa_text,semester_text);
            }
        });
        call.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intentCall = new Intent(Intent.ACTION_DIAL);
                intentCall.setData(Uri.parse("tel:03314332130"));
                startActivity(intentCall);
            }
        });

        send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intentSendMessage=new Intent(Intent.ACTION_SENDTO,Uri.parse("smsto:03314332130"));
                intentSendMessage.putExtra("sms_body","Hello, we're testing our app!");
                startActivity(intentSendMessage);
            }
        });

    }

    private void editImplementation(String name,String father,String reg, String cgpa,String semester){
        Bundle editState=new Bundle();
        editState.putString(KEY_NAME,name);
        editState.putString(KEY_FATHERNAME,father);
        editState.putString(KEY_REG,reg);
        editState.putString(KEY_CGPA,cgpa);
        editState.putString(KEY_SEMESTER,semester);

        Intent returnToMainIntent=new Intent(this, MainActivity.class);
        returnToMainIntent.putExtra("editState",editState);
        startActivity(returnToMainIntent);
    }
}
