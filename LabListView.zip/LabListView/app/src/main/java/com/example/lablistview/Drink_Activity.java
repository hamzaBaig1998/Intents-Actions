package com.example.lablistview;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class Drink_Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_drink_);

        //get drink from intent
        int arrayId=(Integer)getIntent().getExtras().get("drinkId");
        int item=(Integer)getIntent().getExtras().get("item");

        ImageView logo=(ImageView) findViewById(R.id.photo);
        TextView description=(TextView) findViewById(R.id.description);
        TextView title=(TextView) findViewById(R.id.name);

        //Populate drink
        if(item==0) {
            Drink drink=Drink.drinks[arrayId];
            title.setText(drink.getTitle());
            description.setText(drink.getDescription());
            logo.setImageResource(drink.getLogo());
            logo.setContentDescription(drink.getTitle());
        }
        else if(item==1){
            Food food=Food.food[arrayId];
            title.setText(food.getTitle());
            description.setText(food.getDescription());
            logo.setImageResource(food.getLogo());
            logo.setContentDescription(food.getDescription());
        }
        else if(item==2){
            Store store=Store.store[arrayId];
            title.setText(store.getTitle());
            description.setText(store.getDescription());
            logo.setImageResource(store.getLogo());
            logo.setContentDescription(store.getTitle());
        }
        ActionBar actionBar=getSupportActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);
    }
}
