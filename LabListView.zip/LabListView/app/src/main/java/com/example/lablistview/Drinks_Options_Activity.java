package com.example.lablistview;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

public class Drinks_Options_Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_drinks__options_);
        int item=(Integer)getIntent().getIntExtra("item",0);

        ArrayAdapter<Drink> listAdapter=new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,Drink.drinks);
        ArrayAdapter<Food> foodAdapter=new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,Food.food);
        ArrayAdapter<Store> storeAdapter=new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,Store.store);

        ListView listDrinks=(ListView) findViewById(R.id.list_drinks);
        if(item==0){
            listDrinks.setAdapter(listAdapter);
        }
        else if(item==1){
            listDrinks.setAdapter(foodAdapter);
        }
        else if(item==2){
            listDrinks.setAdapter(storeAdapter);
        }

        if(item==0){
            AdapterView.OnItemClickListener itemClickListener=new AdapterView.OnItemClickListener(){
                public void onItemClick(AdapterView<?> listDrinks, View itemView, int position,long id){
//                Toast.makeText(Drinks_Options_Activity.this,"Coffee",Toast.LENGTH_SHORT).show();
                    Intent intent=new Intent(Drinks_Options_Activity.this, Drink_Activity.class);
                    intent.putExtra("drinkId",(int)id);
                    intent.putExtra("item",0);
                    startActivity(intent);
                }
            };
            listDrinks.setOnItemClickListener(itemClickListener);
        }
        else if(item==1){
            AdapterView.OnItemClickListener itemClickListener=new AdapterView.OnItemClickListener(){
                public void onItemClick(AdapterView<?> listDrinks, View itemView, int position,long id){
//                Toast.makeText(Drinks_Options_Activity.this,"Coffee",Toast.LENGTH_SHORT).show();
                    Intent intent=new Intent(Drinks_Options_Activity.this, Drink_Activity.class);
                    intent.putExtra("drinkId",(int)id);
                    intent.putExtra("item",1);
                    startActivity(intent);
                }
            };
            listDrinks.setOnItemClickListener(itemClickListener);
        }
        else if(item==2){
            AdapterView.OnItemClickListener itemClickListener=new AdapterView.OnItemClickListener(){
                public void onItemClick(AdapterView<?> listDrinks, View itemView, int position,long id){
//                Toast.makeText(Drinks_Options_Activity.this,"Coffee",Toast.LENGTH_SHORT).show();
                    Intent intent=new Intent(Drinks_Options_Activity.this, Drink_Activity.class);
                    intent.putExtra("drinkId",(int)id);
                    intent.putExtra("item",2);
                    startActivity(intent);
                }
            };
            listDrinks.setOnItemClickListener(itemClickListener);
        }

        ActionBar actionBar=getSupportActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);
    }
}
